import numpy as np

data_cyc = np.load(r"C:\Users\anton\OneDrive\Documents\GitHub\Experimental_Capstone\Sim_data\sim_data_cyc_Rota.npz")
thrust_cyc = data_cyc["thrust_log"]
t_cyc = data_cyc["t_log"]
state_cyc = data_cyc["state_log"]

dt_cyc = t_cyc[1]-t_cyc[0]
ubar = 25/1000

data_mod = np.load(r"C:\Users\anton\OneDrive\Documents\GitHub\Experimental_Capstone\Sim_data\sim_data_mod_Rota.npz")
thrust_mod = data_mod["thrust_log"]
t_mod = data_mod["t_log"]
state_mod = data_mod["state_log"]

dt_mod = t_mod[1]-t_mod[0]

Tot_ISP_cyc = sum(sum(thrust_cyc))*dt_cyc

Tot_ISP_mod = sum(sum(thrust_mod))*dt_mod # no need to add *ubar, already accounted for in the simulation


print("The Convergance for cyc is:", round(max(t_cyc),3),"s")
print("The Convergance for mod is:", round(max(t_mod),3),"s")


print("The Total ISP for cyc is:", round(Tot_ISP_cyc,3))
print("The Total ISP for mod is:", round(Tot_ISP_mod,3))

print(thrust_mod)